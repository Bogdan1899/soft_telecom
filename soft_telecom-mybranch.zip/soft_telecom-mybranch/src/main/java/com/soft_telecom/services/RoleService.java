package com.soft_telecom.services;


import com.soft_telecom.entities.Role;

import java.util.List;

public interface RoleService {

    Role getDefaultRole();
}
