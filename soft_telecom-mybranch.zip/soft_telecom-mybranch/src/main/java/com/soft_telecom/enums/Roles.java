package com.soft_telecom.enums;


public enum Roles {
    ROLE_ADMIN, ROLE_USER
}
