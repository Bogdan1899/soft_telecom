package com.soft_telecom.enums;


public enum PlanType {
    MOBILE, TV_INTERNET
}
