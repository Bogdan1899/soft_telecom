package com.soft_telecom.configuration;

public class Errors {

    public static final String INVALID_CREDENTIALS = "Invalid credentials";
}
