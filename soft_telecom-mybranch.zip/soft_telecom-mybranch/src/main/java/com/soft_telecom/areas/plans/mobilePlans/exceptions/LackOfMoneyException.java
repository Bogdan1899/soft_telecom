package com.soft_telecom.areas.plans.mobilePlans.exceptions;


public class LackOfMoneyException extends Exception{

}
